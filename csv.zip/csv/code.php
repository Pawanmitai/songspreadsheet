<?php

require 'vendor/autoload.php';
session_start();
// echo $_SESSION['status']='hello';
// die;
$conn=mysqli_connect("localhost","root","","music");

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
if(isset($_POST['Import']))
{
	$allowed_ext=['xls','csv','xlsx'];
	$fileName=$_FILES['file']['name'];
	$checking= explode('.',$fileName);
	$file_ext=end($checking);

	if(in_array($file_ext, $allowed_ext))
	{
		$targetpath = $_FILES['file']['tmp_name'];
		$spreadsheet = \PhpOffice\PhpSpreadsheet\IOFactory::load($targetpath);
		$data=$spreadsheet->getActiveSheet()->toArray();
		foreach ($data as $row) 
		{
			$id=$row[0];
			$songs=$row[1];
			$artist=$row[2];
			$duration=$row[3];
			$status='Y';

			$checking="SELECT id from album where id='$id'";
			$chekingsongs=mysqli_query($conn,$checking);
			// echo mysqli_num_rows($chekingsongs);
			// die;
			if(mysqli_num_rows($chekingsongs)>0)
			{
				$update="UPDATE album SET songs='$songs',artist='$artist',duration='$duration',status='$status' where id='$id' ";
				$updated=mysqli_query($conn,$update);
				$msg=1;
			}
			else
			{
				$insert="INSERT INTO album(id,songs,artist,duration, status) VALUES ('$id','$songs','$artist','$duration','$status') ";
				$inserted=mysqli_query($conn,$insert);
				$msg=1;

			}


			
		}
			$delete="DELETE FROM ALBUM WHERE id='0'";
			mysqli_query($conn,$delete);

		if(isset($msg))
		{
			$_SESSION['status']='File Imported Sucessfully';
			header('location: index.php');
		}
		else
		{
			$_SESSION['status']='File Importing Failed';
			header('location: index.php');
		}


	}
	else
	{
		$_SESSION['status']='Invalid file';
		header('location: index.php');
		exit(0);
	}
}


	
	 function get_all_records(){
        $con = getdb();
        $Sql = "SELECT * FROM album order by duration desc group by artist";
        $result = mysqli_query($conn, $Sql);  
        if (mysqli_num_rows($result) > 0) {
         echo "<div class='table-responsive'><table id='myTable' class='table table-striped table-bordered'>
                 <thead><tr><th>ID</th>
                              <th>Song Name</th>
                              <th>Artist Name</th>
                              <th>Duration</th>
                              <th>Status</th>
                            </tr></thead><tbody>";
         while($row = mysqli_fetch_assoc($result)) {
             echo "<tr><td>" . $row['id']."</td>
                       <td>" . $row['songs']."</td>
                       <td>" . $row['artist']."</td>
                       <td>" . $row['duration']."</td>
                       <td>" . $row['status']."</td></tr>";        
         }
        
         echo "</tbody></table></div>";
         
    } else {
         echo "No Records Found..";
    }
    }

?>