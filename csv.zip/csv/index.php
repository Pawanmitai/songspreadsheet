    <?php
    session_start();
   
     function get_all_records(){
        $conn=mysqli_connect("localhost","root","","music");
        $Sql = "SELECT artist FROM album GROUP BY artist ORDER BY duration DESC";
        $result = mysqli_query($conn,$Sql); 
       

        if (mysqli_num_rows($result)>0) {
         echo "<div class='table-responsive'><table id='myTable' class='table  table-bordered'>
                 <thead><tr><th>Artist Name</th>
                              <th>Song Name</th>
                              <th>Duration</th>
                              <th>Status</th>
                            </tr></thead><tbody>";
                            $i=1;
        while($rows = mysqli_fetch_assoc($result)) {
                $artist= $rows['artist'];
                 $Sql2 = "SELECT * FROM album WHERE artist='$artist' ORDER BY duration DESC ";
                echo "<tr ><td>" .$rows['artist']."</td>";
                 $result2 = mysqli_query($conn,$Sql2);
                 
         while($row = mysqli_fetch_assoc($result2)) {
             echo "<tr><td></td>
                       <td>" . $row['songs']."</td>
                       <td>" . $row['duration']."</td>
                       <td>" . $row['status']."</td></tr>";   
                       $i++;     
         }
         echo "</tr>";
     }
        
         echo "</tbody></table></div>";
         
    } else {
         echo "No Records Found..";
    }
    }
	?>
	<!DOCTYPE html>
    <html lang="en">
    <head>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" >
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    </head>
    <body>
        <div id="wrap">
            <div class="container">
                <div class="row">
                    <?php
                        if(isset($_SESSION['status']))
                        {
                            echo '<h5>'.$_SESSION['status'].'</h5>';
                            unset($_SESSION['status']);
                        }
                    ?>
                    <form class="form-horizontal" action="code.php" method="post" name="upload_excel" enctype="multipart/form-data">
                        <fieldset>
                            <!-- Form Name -->
                            <legend>Import From CSV or Xlxs</legend>
                            <!-- File Button -->
                            <div class="form-group">
                                <label class="col-md-4 control-label" for="filebutton">Select File</label>
                                <div class="col-md-4">
                                    <input type="file" name="file" id="file" class="input-large" required>
                                </div>
                            </div>
                            <!-- Button -->
                            <div class="form-group">
                                <label class="col-md-4 control-label" for="singlebutton">Import data</label>
                                <div class="col-md-4">
                                    <button type="submit" id="submit" name="Import" class="btn btn-primary button-loading" data-loading-text="Loading...">Upload</button>
                                </div>
                            </div>
                        </fieldset>
                    </form>
                </div>
                <?php
                   get_all_records();
                ?>
				     <!-- <div>
                        <form class="form-horizontal" action="functions.php" method="post" name="upload_excel"   
                                  enctype="multipart/form-data">
                              <div class="form-group">
                                        <div class="col-md-4 col-md-offset-4">
                                            <input type="submit" name="Export" class="btn btn-success" value="export to excel"/>
                                        </div>
                               </div>                    
                        </form>           
                    </div> -->
            </div>
        </div>
    </body>
    </html>